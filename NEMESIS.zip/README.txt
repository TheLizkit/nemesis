███╗░░██╗███████╗███╗░░░███╗███████╗░██████╗██╗░██████╗░░░███████╗██╗░░██╗███████╗
████╗░██║██╔════╝████╗░████║██╔════╝██╔════╝██║██╔════╝░░░██╔════╝╚██╗██╔╝██╔════╝
██╔██╗██║█████╗░░██╔████╔██║█████╗░░╚█████╗░██║╚█████╗░░░░█████╗░░░╚███╔╝░█████╗░░
██║╚████║██╔══╝░░██║╚██╔╝██║██╔══╝░░░╚═══██╗██║░╚═══██╗░░░██╔══╝░░░██╔██╗░██╔══╝░░
██║░╚███║███████╗██║░╚═╝░██║███████╗██████╔╝██║██████╔╝██╗███████╗██╔╝╚██╗███████╗
╚═╝░░╚══╝╚══════╝╚═╝░░░░░╚═╝╚══════╝╚═════╝░╚═╝╚═════╝░╚═╝╚══════╝╚═╝░░╚═╝╚══════╝

Created by: Lizkit
Coding Language: C++
Programs Used: Visual Studio 2022 v17.12.4, Dev-C++
Supported OS: Windows XP and over.
This program will not work with previous versions.

THIS PROGRAM IS MALICIOUS AND CAN CAUSE SIGNIFICANT DAMAGE TO YOUR SYSTEM.
UPON EXECUTING, YOU WILL BE GREETED WITH A WARNING TO CONFIRM YOUR DECISION.

This program has flashing lights and loud noises.

Enjoy :)